import fabric.main
fabric.main.main()
