from __future__ import absolute_import
import regex as re


RE_DELIMITER = re.compile('\r?\n')
