class UnknownExtension(Exception):
    pass


class UnknownFormat(Exception):
    pass
