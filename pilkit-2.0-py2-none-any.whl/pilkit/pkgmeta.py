__title__ = 'pilkit'
__author__ = 'Matthew Tretter'
__version__ = '2.0'
__license__ = 'BSD'
__all__ = ['__title__', '__author__', '__version__', '__license__']
