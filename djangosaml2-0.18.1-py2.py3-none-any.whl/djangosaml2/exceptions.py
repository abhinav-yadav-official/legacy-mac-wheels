class IdPConfigurationMissing(Exception):
    pass
