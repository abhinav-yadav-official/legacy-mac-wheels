# tags
NAME = "db.name"  # the database name (eg: dbname for pgsql)
USER = "db.user"  # the user connecting to the db
SYSTEM = "db.system"  # the database's DBMS name (e.g. postgresql for pgsql)
ROWCOUNT = "db.row_count"  # the rowcount of a query
SYSTEM = "db.system"  # the database's DBMS name (e.g. postgresql for pgsql)
