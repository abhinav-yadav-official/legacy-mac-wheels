"""Auto-generated file, do not edit by hand. 64 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_64 = [NumberFormat(pattern='(\\d)(\\d{4})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['[3467]|9[2-9]']), NumberFormat(pattern='(\\d{3})(\\d{3})(\\d{2})', format='\\1 \\2 \\3', leading_digits_pattern=['[89]0'])]
