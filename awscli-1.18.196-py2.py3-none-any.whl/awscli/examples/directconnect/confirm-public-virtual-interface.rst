**To accept ownership of a public virtual interface**

The following ``confirm-public-virtual-interface`` command accepts ownership of a public virtual interface created by another customer::

  aws directconnect confirm-public-virtual-interface --virtual-interface-id dxvif-fg9xo9vp

Output::

  {
      "virtualInterfaceState": "verifying"
  }