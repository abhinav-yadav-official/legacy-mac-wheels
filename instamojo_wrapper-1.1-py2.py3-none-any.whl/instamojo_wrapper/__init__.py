__version__ = '1.1'

from .api import Instamojo
