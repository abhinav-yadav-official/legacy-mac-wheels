COMPONENT_VALUE = "unittest"
FRAMEWORK = "unittest"
KIND = "test"

TEST_OPERATION_NAME = "unittest.test"
